Project 1

Tri Khuu tkkhuu
Max Kinney mbkinney

Phase 1: runCommand

- In phase 1 after parsing to get the input commands (ls, cd, pwd, etc.) from the user. We fork a new child process to execute that command using execvp. If the fork fail, the child process exit and print an error message. If the fork succeeds, It will execute the command.

Phase 2: shell

- Similar to phase 1, but in this case there will be an infinite loop to keep receiving commands from the user. Everytime a command is entered, the program fork a child process to execute it and wait until that process return. Then it prompts the user to enter a new command.

Phase 3: shell2

- In phase 3, since we have to keep track of all the background processes by creating a linked list of pid_node.
- pid_node is a struct that stores all the information of a process including process ID, resource usage, finished or unfinished, wall clock time and a pointer to the next process in the list.
- We store the head reference of the linked list as a global variable, everytime a background process is created, a pid_node is created and added to the list. Once wait4 return this process, it will mark the process as finished and delete the process from the list.
- When we call jobs, it will iterate through the list of background process and print out the information of the process that has not finished.


Problems encountered:
- We weren't able to store the command of background processes to print out and we couldn't figure out the reason, instead, we printed out its process id.
- We didn't have enough time to test against long process, most processes that we tested returns before the next command.

